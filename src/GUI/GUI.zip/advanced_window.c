/*
 * advanced_window.c - iTidy Advanced Settings Window Implementation
 * GadTools-based GUI for Workbench 3.0+
 * Aspect Ratio and Window Overflow Configuration
 */

#include <exec/types.h>
#include <exec/memory.h>
#include <intuition/intuition.h>
#include <intuition/screens.h>
#include <libraries/gadtools.h>
#include <proto/exec.h>
#include <proto/intuition.h>
#include <proto/gadtools.h>
#include <proto/graphics.h>
#include <string.h>
#include <stdio.h>

#include "advanced_window.h"
#include "beta_options_window.h"
#include "layout_preferences.h"
#include "writeLog.h"

/*------------------------------------------------------------------------*/
/* Window & Layout Constants                                              */
/*------------------------------------------------------------------------*/
#define ITIDY_ADV_WINDOW_TITLE           "iTidy - Advanced Settings"
#define ITIDY_ADV_WINDOW_WIDTH_CHARS     60
#define ITIDY_ADV_WINDOW_LEFT            100
#define ITIDY_ADV_WINDOW_TOP             50

#define ITIDY_ADV_MARGIN_LEFT            15
#define ITIDY_ADV_MARGIN_TOP             10
#define ITIDY_ADV_MARGIN_RIGHT           15
#define ITIDY_ADV_MARGIN_BOTTOM          10

#define ITIDY_ADV_SPACE_X                8
#define ITIDY_ADV_SPACE_Y                6
#define ITIDY_ADV_GROUP_VGAP_ROWS        1
#define ITIDY_ADV_INLINE_LABEL_PAD       6

#define ITIDY_ADV_MIN_GADGET_COL_WIDTH   150
#define ITIDY_ADV_MIN_CYCLE_WIDTH         140
#define ITIDY_ADV_SMALL_FIELD_WIDTH      60
#define ITIDY_ADV_MEDIUM_FIELD_WIDTH     100
#define ITIDY_ADV_BETA_BUTTON_WIDTH      140
#define ITIDY_ADV_BUTTON_TEXT_PADDING    20

/*------------------------------------------------------------------------*/
/* Cycle Gadget Labels                                                   */
/*------------------------------------------------------------------------*/
static STRPTR aspect_ratio_labels[] = {
    "Tall (0.75)",
    "Square (1.0)",
    "Compact (1.3)",
    "Classic (1.6)",
    "Wide (2.0)",
    "Ultrawide (2.4)",
    "Custom",
    NULL
};

static STRPTR overflow_mode_labels[] = {
    "Expand Horizontally",
    "Expand Vertically",
    "Expand Both",
    NULL
};

static STRPTR max_width_pct_labels[] = {
    "Auto",
    "30%",
    "50%",
    "70%",
    "90%",
    "100%",
    NULL
};

static STRPTR vertical_align_labels[] = {
    "Top",
    "Middle",
    "Bottom",
    NULL
};

static const char *adv_label_texts[] = {
    "Layout Aspect Ratio:",
    "Custom Ratio:",
    "Overflow Strategy:",
    "Spacing:",
    "Icons per Row:",
    "Max Window Width (% Screen):",
    "Align Icons Vertically:",
    "Layout & Spacing",
    "Window Size",
    "Sorting & Behaviour"
};

enum { ADV_LABEL_TEXTS_COUNT = (sizeof(adv_label_texts) / sizeof(adv_label_texts[0])) };

/*------------------------------------------------------------------------*/
/* Aspect Ratio Preset Values (Fixed-Point: Scaled by 1000)             */
/*------------------------------------------------------------------------*/
static const int aspect_ratio_presets[] = {
    750,   /* Tall (0.75 * 1000) */
    1000,  /* Square (1.0 * 1000) */
    1300,  /* Compact (1.3 * 1000) */
    1600,  /* Classic (1.6 * 1000) */
    2000,  /* Wide (2.0 * 1000) */
    2400,  /* Ultrawide (2.4 * 1000) */
    0      /* Custom (calculated from width:height) */
};

/*------------------------------------------------------------------------*/
/* Helper Functions                                                       */
/*------------------------------------------------------------------------*/

static UWORD measure_text(struct RastPort *rp, const char *text)
{
    if (!rp || !text)
    {
        return 0;
    }

    return TextLength(rp, (CONST_STRPTR)text, strlen(text));
}

static void init_new_gadget(struct NewGadget *ng,
                            struct iTidyAdvancedWindow *adv_data,
                            struct TextAttr *text_attr)
{
    if (!ng)
    {
        return;
    }

    memset(ng, 0, sizeof(*ng));
    ng->ng_VisualInfo = adv_data ? adv_data->visual_info : NULL;
    ng->ng_TextAttr = text_attr;
}

static void update_content_bottom(UWORD *current_bottom, UWORD top, UWORD height)
{
    UWORD bottom;

    if (!current_bottom)
    {
        return;
    }

    bottom = top + height;
    if (bottom > *current_bottom)
    {
        *current_bottom = bottom;
    }
}

/**
 * @brief Determine which preset matches the current aspect ratio
 *
 * @param prefs Pointer to LayoutPreferences
 * @return WORD Preset index (0-6), or ASPECT_PRESET_CUSTOM if custom
 */
static WORD get_aspect_ratio_preset_index(const LayoutPreferences *prefs)
{
    int i;
    
    /* Check if using custom aspect ratio */
    if (prefs->useCustomAspectRatio)
    {
        return ASPECT_PRESET_CUSTOM;
    }
    
    /* Find matching preset (allow small differences due to rounding) */
    for (i = 0; i < 6; i++)
    {
        int diff = prefs->aspectRatio - aspect_ratio_presets[i];
        if (diff < 0) diff = -diff;  /* abs() */
        
        if (diff < 10)  /* Within tolerance (0.01 * 1000) */
        {
            return i;
        }
    }
    
    /* Default to Classic if no match */
    return ASPECT_PRESET_CLASSIC;
}

/**
 * @brief Get max window width percentage index from actual percentage value
 *
 * @param pct Percentage value (0-100)
 * @return WORD Index (0=Auto, 1=30%, 2=50%, 3=70%, 4=90%, 5=100%)
 */
static WORD get_max_width_pct_index(UWORD pct)
{
    /* Map common preset values to indices */
    switch (pct)
    {
        case 30: return MAX_WIDTH_30;
        case 50: return MAX_WIDTH_50;
        case 70: return MAX_WIDTH_70;
        case 90: return MAX_WIDTH_90;
        case 100: return MAX_WIDTH_100;
        default: return MAX_WIDTH_AUTO;  /* Anything else defaults to Auto */
    }
}

/**
 * @brief Get actual percentage value from max window width index
 *
 * @param index Index (0-5)
 * @param prefs Current preferences (for Auto default)
 * @return UWORD Percentage value (0-100), 0 means use preset default
 */
static UWORD get_max_width_pct_value(WORD index, const LayoutPreferences *prefs)
{
    switch (index)
    {
        case MAX_WIDTH_30: return 30;
        case MAX_WIDTH_50: return 50;
        case MAX_WIDTH_70: return 70;
        case MAX_WIDTH_90: return 90;
        case MAX_WIDTH_100: return 100;
        case MAX_WIDTH_AUTO:
        default:
            return 0;  /* 0 = Auto, means use preset default */
    }
}

/**
 * @brief Create all gadgets for the advanced settings window
 *
 * @param adv_data Pointer to advanced window data structure
 * @return struct Gadget* Pointer to gadget list, or NULL on failure
 */
static struct Gadget *create_advanced_gadgets(struct iTidyAdvancedWindow *adv_data,
                                              UWORD *out_window_width,
                                              UWORD *out_window_height)
{
    struct Screen *screen;
    struct DrawInfo *draw_info = NULL;
    struct RastPort temp_rp;
    struct Gadget *gad = NULL;
    struct Gadget *result = NULL;
    struct NewGadget ng;
    struct TextAttr *text_attr;
    struct TextFont *font = NULL;
    UWORD font_width = 8;
    UWORD font_height = 8;
    UWORD string_height;
    UWORD checkbox_height;
    UWORD button_height;
    UWORD row_step;
    WORD border_top, border_left, border_right, border_bottom;
    UWORD label_column_x;
    UWORD column_width;
    UWORD gadget_col1_x;
    UWORD gadget_col2_x;
    UWORD reference_width;
    UWORD content_top;
    UWORD content_bottom;
    UWORD row_index = 0;
    UWORD button_row_y;
    UWORD equal_button_width;
    UWORD button_left;
    UWORD window_width = 0;
    UWORD window_height = 0;
    UWORD button_text_ok_width;
    UWORD button_text_cancel_width;
    UWORD spacing_x_label_width;
    UWORD spacing_y_label_width;
    UWORD min_icons_label_width;
    UWORD max_icons_label_width;
    UWORD custom_ratio_w_label_width;
    UWORD custom_ratio_h_label_width;
    UWORD min_required_column_width;
    UWORD adv_max_label_width = 0;
    UWORD baseline_width;
    UWORD row_y;
    UWORD spacing_x_field_width = ITIDY_ADV_SMALL_FIELD_WIDTH;
    UWORD spacing_y_field_width = ITIDY_ADV_SMALL_FIELD_WIDTH;
    UWORD min_icons_field_width = ITIDY_ADV_SMALL_FIELD_WIDTH;
    UWORD max_icons_field_width = ITIDY_ADV_SMALL_FIELD_WIDTH;
    UWORD custom_ratio_field_width = ITIDY_ADV_SMALL_FIELD_WIDTH;
    UWORD beta_button_width = ITIDY_ADV_BETA_BUTTON_WIDTH;
    BOOL success = FALSE;
    UWORD i;

    if (out_window_width) *out_window_width = 0;
    if (out_window_height) *out_window_height = 0;

    if (!adv_data)
    {
        return NULL;
    }

    screen = adv_data->screen;
    if (!screen || !adv_data->visual_info)
    {
        return NULL;
    }

    text_attr = screen->Font;

    draw_info = GetScreenDrawInfo(screen);
    if (!draw_info)
    {
        printf("ERROR: Failed to get screen draw info\n");
        return NULL;
    }

    InitRastPort(&temp_rp);
    temp_rp.BitMap = screen->RastPort.BitMap;
    font = draw_info->dri_Font ? draw_info->dri_Font : screen->RastPort.Font;
    if (font)
    {
        SetFont(&temp_rp, font);
        font_width = font->tf_XSize;
        font_height = font->tf_YSize;
    }

    string_height = font_height + 6;
    checkbox_height = font_height + 4;
    button_height = font_height + 6;
    row_step = string_height + ITIDY_ADV_SPACE_Y;

    border_top = screen->WBorTop + font_height + 1;
    border_left = screen->WBorLeft;
    border_right = screen->WBorRight;
    border_bottom = screen->WBorBottom;

    for (i = 0; i < ADV_LABEL_TEXTS_COUNT; i++)
    {
        UWORD w = measure_text(&temp_rp, adv_label_texts[i]);
        if (w > adv_max_label_width)
        {
            adv_max_label_width = w;
        }
    }

    spacing_x_label_width = measure_text(&temp_rp, "Icon Spacing X");
    spacing_y_label_width = measure_text(&temp_rp, "Icon Spacing Y");
    min_icons_label_width = measure_text(&temp_rp, "Minimum Icons/Row");
    max_icons_label_width = measure_text(&temp_rp, "Maximum Icons/Row");
    custom_ratio_w_label_width = measure_text(&temp_rp, "Custom Ratio: W");
    custom_ratio_h_label_width = measure_text(&temp_rp, "Custom Ratio: H");

    min_required_column_width = ITIDY_ADV_MIN_GADGET_COL_WIDTH;

    if (spacing_x_label_width + ITIDY_ADV_INLINE_LABEL_PAD + spacing_x_field_width > min_required_column_width)
    {
        min_required_column_width = spacing_x_label_width + ITIDY_ADV_INLINE_LABEL_PAD + spacing_x_field_width;
    }
    if (spacing_y_label_width + ITIDY_ADV_INLINE_LABEL_PAD + spacing_y_field_width > min_required_column_width)
    {
        min_required_column_width = spacing_y_label_width + ITIDY_ADV_INLINE_LABEL_PAD + spacing_y_field_width;
    }
    if (min_icons_label_width + ITIDY_ADV_INLINE_LABEL_PAD + min_icons_field_width > min_required_column_width)
    {
        min_required_column_width = min_icons_label_width + ITIDY_ADV_INLINE_LABEL_PAD + min_icons_field_width;
    }
    if (max_icons_label_width + ITIDY_ADV_INLINE_LABEL_PAD + max_icons_field_width > min_required_column_width)
    {
        min_required_column_width = max_icons_label_width + ITIDY_ADV_INLINE_LABEL_PAD + max_icons_field_width;
    }
    if (custom_ratio_w_label_width + ITIDY_ADV_INLINE_LABEL_PAD + custom_ratio_field_width > min_required_column_width)
    {
        min_required_column_width = custom_ratio_w_label_width + ITIDY_ADV_INLINE_LABEL_PAD + custom_ratio_field_width;
    }
    if (custom_ratio_h_label_width + ITIDY_ADV_INLINE_LABEL_PAD + custom_ratio_field_width > min_required_column_width)
    {
        min_required_column_width = custom_ratio_h_label_width + ITIDY_ADV_INLINE_LABEL_PAD + custom_ratio_field_width;
    }
    if (ITIDY_ADV_MIN_CYCLE_WIDTH > min_required_column_width)
    {
        min_required_column_width = ITIDY_ADV_MIN_CYCLE_WIDTH;
    }

    column_width = min_required_column_width;
    reference_width = adv_max_label_width + ITIDY_ADV_SPACE_X + (column_width * 2) + ITIDY_ADV_SPACE_X;
    baseline_width = font_width * ITIDY_ADV_WINDOW_WIDTH_CHARS;
    if (reference_width < baseline_width)
    {
        UWORD delta = baseline_width - reference_width;
        column_width += delta / 2;
        reference_width = adv_max_label_width + ITIDY_ADV_SPACE_X + (column_width * 2) + ITIDY_ADV_SPACE_X;
    }

    label_column_x = border_left + ITIDY_ADV_MARGIN_LEFT;
    gadget_col1_x = label_column_x + adv_max_label_width + ITIDY_ADV_SPACE_X;
    gadget_col2_x = gadget_col1_x + column_width + ITIDY_ADV_SPACE_X;
    content_top = border_top + ITIDY_ADV_MARGIN_TOP;
    content_bottom = content_top;
    button_left = label_column_x;

    if (beta_button_width > column_width)
    {
        beta_button_width = column_width;
    }

    gad = CreateContext(&adv_data->glist);
    if (!gad)
    {
        printf("ERROR: Failed to create gadget context\n");
        goto cleanup;
    }

    /* Layout & Spacing group label */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Layout & Spacing",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create group label\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, string_height);
    row_index++;

    /* Layout Aspect Ratio cycle */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = adv_max_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Layout Aspect Ratio:",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create layout label\n");
        goto cleanup;
    }

    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = column_width;
    ng.ng_Height = button_height;
    ng.ng_GadgetID = GID_ADV_ASPECT_RATIO;
    adv_data->aspect_ratio_cycle = gad = CreateGadget(CYCLE_KIND, gad, &ng,
        GTCY_Labels, aspect_ratio_labels,
        GTCY_Active, adv_data->aspect_preset_selected,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create aspect ratio cycle\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, button_height);
    row_index++;

    /* Custom ratio inputs (W/H) */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = adv_max_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Custom Ratio:",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create custom ratio label\n");
        goto cleanup;
    }

    /* Custom width (W) */
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = custom_ratio_w_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Custom Ratio: W",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create custom width text\n");
        goto cleanup;
    }

    {
        UWORD available = column_width - custom_ratio_w_label_width - ITIDY_ADV_INLINE_LABEL_PAD;
        UWORD field_width = custom_ratio_field_width;
        if (available < field_width)
        {
            field_width = available;
        }
        init_new_gadget(&ng, adv_data, text_attr);
        ng.ng_LeftEdge = gadget_col1_x + custom_ratio_w_label_width + ITIDY_ADV_INLINE_LABEL_PAD;
        ng.ng_TopEdge = row_y;
        ng.ng_Width = field_width;
        ng.ng_Height = string_height;
        ng.ng_GadgetID = GID_ADV_CUSTOM_WIDTH;
        adv_data->custom_width_int = gad = CreateGadget(INTEGER_KIND, gad, &ng,
            GTIN_Number, adv_data->custom_aspect_width,
            GTIN_MaxChars, 3,
            GA_Disabled, (adv_data->aspect_preset_selected != ASPECT_PRESET_CUSTOM),
            TAG_END);
        if (!gad)
        {
            printf("ERROR: Failed to create custom width integer\n");
            goto cleanup;
        }
    }

    /* Custom height (H) */
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col2_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = custom_ratio_h_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Custom Ratio: H",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create custom height text\n");
        goto cleanup;
    }

    {
        UWORD available = column_width - custom_ratio_h_label_width - ITIDY_ADV_INLINE_LABEL_PAD;
        UWORD field_width = custom_ratio_field_width;
        if (available < field_width)
        {
            field_width = available;
        }
        init_new_gadget(&ng, adv_data, text_attr);
        ng.ng_LeftEdge = gadget_col2_x + custom_ratio_h_label_width + ITIDY_ADV_INLINE_LABEL_PAD;
        ng.ng_TopEdge = row_y;
        ng.ng_Width = field_width;
        ng.ng_Height = string_height;
        ng.ng_GadgetID = GID_ADV_CUSTOM_HEIGHT;
        adv_data->custom_height_int = gad = CreateGadget(INTEGER_KIND, gad, &ng,
            GTIN_Number, adv_data->custom_aspect_height,
            GTIN_MaxChars, 3,
            GA_Disabled, (adv_data->aspect_preset_selected != ASPECT_PRESET_CUSTOM),
            TAG_END);
        if (!gad)
        {
            printf("ERROR: Failed to create custom height integer\n");
            goto cleanup;
        }
    }

    update_content_bottom(&content_bottom, row_y, string_height);
    row_index++;

    /* Overflow Strategy (separate row for clarity per template fallback) */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = adv_max_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Overflow Strategy:",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create overflow label\n");
        goto cleanup;
    }

    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = column_width;
    ng.ng_Height = button_height;
    ng.ng_GadgetID = GID_ADV_OVERFLOW_MODE;
    adv_data->overflow_mode_cycle = gad = CreateGadget(CYCLE_KIND, gad, &ng,
        GTCY_Labels, overflow_mode_labels,
        GTCY_Active, adv_data->overflow_mode_selected,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create overflow cycle\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, button_height);
    row_index++;

    /* Spacing row */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = adv_max_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Spacing:",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create spacing label\n");
        goto cleanup;
    }

    /* Icon Spacing X */
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = spacing_x_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Icon Spacing X",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create spacing X text\n");
        goto cleanup;
    }

    {
        UWORD available = column_width - spacing_x_label_width - ITIDY_ADV_INLINE_LABEL_PAD;
        UWORD field_width = spacing_x_field_width;
        if (available < field_width)
        {
            field_width = available;
        }
        init_new_gadget(&ng, adv_data, text_attr);
        ng.ng_LeftEdge = gadget_col1_x + spacing_x_label_width + ITIDY_ADV_INLINE_LABEL_PAD;
        ng.ng_TopEdge = row_y;
        ng.ng_Width = field_width;
        ng.ng_Height = string_height;
        ng.ng_GadgetID = GID_ADV_SPACING_X;
        adv_data->spacing_x_int = gad = CreateGadget(INTEGER_KIND, gad, &ng,
            GTIN_Number, adv_data->spacing_x_value,
            GTIN_MaxChars, 2,
            TAG_END);
        if (!gad)
        {
            printf("ERROR: Failed to create spacing X integer\n");
            goto cleanup;
        }
    }

    /* Icon Spacing Y */
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col2_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = spacing_y_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Icon Spacing Y",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create spacing Y text\n");
        goto cleanup;
    }

    {
        UWORD available = column_width - spacing_y_label_width - ITIDY_ADV_INLINE_LABEL_PAD;
        UWORD field_width = spacing_y_field_width;
        if (available < field_width)
        {
            field_width = available;
        }
        init_new_gadget(&ng, adv_data, text_attr);
        ng.ng_LeftEdge = gadget_col2_x + spacing_y_label_width + ITIDY_ADV_INLINE_LABEL_PAD;
        ng.ng_TopEdge = row_y;
        ng.ng_Width = field_width;
        ng.ng_Height = string_height;
        ng.ng_GadgetID = GID_ADV_SPACING_Y;
        adv_data->spacing_y_int = gad = CreateGadget(INTEGER_KIND, gad, &ng,
            GTIN_Number, adv_data->spacing_y_value,
            GTIN_MaxChars, 2,
            TAG_END);
        if (!gad)
        {
            printf("ERROR: Failed to create spacing Y integer\n");
            goto cleanup;
        }
    }

    update_content_bottom(&content_bottom, row_y, string_height);
    row_index++;

    /* Icons per Row */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = adv_max_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Icons per Row:",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create icons row label\n");
        goto cleanup;
    }

    /* Minimum Icons */
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = min_icons_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Minimum Icons/Row",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create min icons text\n");
        goto cleanup;
    }

    {
        UWORD available = column_width - min_icons_label_width - ITIDY_ADV_INLINE_LABEL_PAD;
        UWORD field_width = min_icons_field_width;
        if (available < field_width)
        {
            field_width = available;
        }
        init_new_gadget(&ng, adv_data, text_attr);
        ng.ng_LeftEdge = gadget_col1_x + min_icons_label_width + ITIDY_ADV_INLINE_LABEL_PAD;
        ng.ng_TopEdge = row_y;
        ng.ng_Width = field_width;
        ng.ng_Height = string_height;
        ng.ng_GadgetID = GID_ADV_MIN_ICONS_ROW;
        adv_data->min_icons_row_int = gad = CreateGadget(INTEGER_KIND, gad, &ng,
            GTIN_Number, adv_data->min_icons_per_row,
            GTIN_MaxChars, 2,
            TAG_END);
        if (!gad)
        {
            printf("ERROR: Failed to create min icons integer\n");
            goto cleanup;
        }
    }

    /* Maximum Icons */
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col2_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = max_icons_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Maximum Icons/Row",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create max icons text\n");
        goto cleanup;
    }

    {
        UWORD available = column_width - max_icons_label_width - ITIDY_ADV_INLINE_LABEL_PAD;
        UWORD field_width = max_icons_field_width;
        if (available < field_width)
        {
            field_width = available;
        }
        init_new_gadget(&ng, adv_data, text_attr);
        ng.ng_LeftEdge = gadget_col2_x + max_icons_label_width + ITIDY_ADV_INLINE_LABEL_PAD;
        ng.ng_TopEdge = row_y;
        ng.ng_Width = field_width;
        ng.ng_Height = string_height;
        ng.ng_GadgetID = GID_ADV_MAX_ICONS_ROW;
        adv_data->max_icons_row_int = gad = CreateGadget(INTEGER_KIND, gad, &ng,
            GTIN_Number, adv_data->max_icons_per_row > 0 ? adv_data->max_icons_per_row : 5,
            GTIN_MaxChars, 2,
            GA_Disabled, adv_data->max_auto_enabled,
            TAG_END);
        if (!gad)
        {
            printf("ERROR: Failed to create max icons integer\n");
            goto cleanup;
        }
    }

    update_content_bottom(&content_bottom, row_y, string_height);
    row_index++;

    /* Automatic Max checkbox row */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = checkbox_height;
    ng.ng_GadgetID = GID_ADV_MAX_AUTO_CHECKBOX;
    ng.ng_GadgetText = "Automatic Max Icons/Row";
    ng.ng_Flags = PLACETEXT_RIGHT;
    adv_data->max_auto_checkbox = gad = CreateGadget(CHECKBOX_KIND, gad, &ng,
        GTCB_Checked, adv_data->max_auto_enabled,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create auto max checkbox\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, checkbox_height);
    row_index++;

    /* Group gap before Window Size */
    row_index += 1 + ITIDY_ADV_GROUP_VGAP_ROWS;

    /* Window Size group label */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Window Size",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create window size label\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, string_height);
    row_index++;

    /* Max Window Width cycle */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = adv_max_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Max Window Width (% Screen):",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create max width label\n");
        goto cleanup;
    }

    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = column_width;
    ng.ng_Height = button_height;
    ng.ng_GadgetID = GID_ADV_MAX_WIDTH_PCT;
    adv_data->max_width_pct_cycle = gad = CreateGadget(CYCLE_KIND, gad, &ng,
        GTCY_Labels, max_width_pct_labels,
        GTCY_Active, adv_data->max_width_pct_selected,
        GA_Disabled, !adv_data->max_auto_enabled,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create max width cycle\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, button_height);
    row_index++;

    /* Align Icons Vertically */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = adv_max_label_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Align Icons Vertically:",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create align label\n");
        goto cleanup;
    }

    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = column_width;
    ng.ng_Height = button_height;
    ng.ng_GadgetID = GID_ADV_VERTICAL_ALIGN;
    adv_data->vertical_align_cycle = gad = CreateGadget(CYCLE_KIND, gad, &ng,
        GTCY_Labels, vertical_align_labels,
        GTCY_Active, adv_data->vertical_align_selected,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create align cycle\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, button_height);
    row_index++;

    /* Group gap before Sorting */
    row_index += 1 + ITIDY_ADV_GROUP_VGAP_ROWS;

    /* Sorting & Behaviour label */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = string_height;
    gad = CreateGadget(TEXT_KIND, gad, &ng,
        GTTX_Text, "Sorting & Behaviour",
        GTTX_Border, FALSE,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create sorting label\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, string_height);
    row_index++;

    /* Reverse Sort checkbox (arrow per UI spec) */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = checkbox_height;
    ng.ng_GadgetID = GID_ADV_REVERSE_SORT;
    ng.ng_GadgetText = "Reverse Sort (Z→A)";
    ng.ng_Flags = PLACETEXT_RIGHT;
    adv_data->reverse_sort_check = gad = CreateGadget(CHECKBOX_KIND, gad, &ng,
        GTCB_Checked, adv_data->reverse_sort_enabled,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create reverse sort checkbox\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, checkbox_height);
    row_index++;

    /* Optimize Column Widths */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = checkbox_height;
    ng.ng_GadgetID = GID_ADV_OPTIMIZE_COLS;
    ng.ng_GadgetText = "Optimize Column Widths";
    ng.ng_Flags = PLACETEXT_RIGHT;
    adv_data->optimize_cols_check = gad = CreateGadget(CHECKBOX_KIND, gad, &ng,
        GTCB_Checked, adv_data->optimize_cols_enabled,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create optimize checkbox\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, checkbox_height);
    row_index++;

    /* Column Layout checkbox */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = checkbox_height;
    ng.ng_GadgetID = GID_ADV_COLUMN_LAYOUT;
    ng.ng_GadgetText = "Column Layout (centered columns)";
    ng.ng_Flags = PLACETEXT_RIGHT;
    adv_data->column_layout_check = gad = CreateGadget(CHECKBOX_KIND, gad, &ng,
        GTCB_Checked, adv_data->column_layout_enabled,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create column layout checkbox\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, checkbox_height);
    row_index++;

    /* Skip Hidden Folders */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = label_column_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = reference_width;
    ng.ng_Height = checkbox_height;
    ng.ng_GadgetID = GID_ADV_SKIP_HIDDEN;
    ng.ng_GadgetText = "Skip Hidden Folders";
    ng.ng_Flags = PLACETEXT_RIGHT;
    adv_data->skip_hidden_check = gad = CreateGadget(CHECKBOX_KIND, gad, &ng,
        GTCB_Checked, adv_data->skip_hidden_enabled,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create skip hidden checkbox\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, checkbox_height);
    row_index++;

    /* Beta Options button */
    row_y = content_top + (row_index * row_step);
    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = gadget_col1_x;
    ng.ng_TopEdge = row_y;
    ng.ng_Width = beta_button_width;
    ng.ng_Height = button_height;
    ng.ng_GadgetID = GID_ADV_BETA_OPTIONS;
    ng.ng_Flags = PLACETEXT_IN;
    ng.ng_GadgetText = "Beta Options...";
    adv_data->beta_options_btn = gad = CreateGadget(BUTTON_KIND, gad, &ng,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create beta options button\n");
        goto cleanup;
    }
    update_content_bottom(&content_bottom, row_y, button_height);
    row_index++;

    /* Equal-width OK/Cancel buttons */
    button_row_y = content_top + (row_index * row_step);
    button_text_ok_width = measure_text(&temp_rp, "OK");
    button_text_cancel_width = measure_text(&temp_rp, "Cancel");
    {
        UWORD max_btn_text = button_text_ok_width;
        if (button_text_cancel_width > max_btn_text)
        {
            max_btn_text = button_text_cancel_width;
        }
        UWORD min_button_width = max_btn_text + ITIDY_ADV_BUTTON_TEXT_PADDING;
        equal_button_width = (reference_width - ITIDY_ADV_SPACE_X) / 2;
        if (equal_button_width < min_button_width)
        {
            equal_button_width = min_button_width;
        }
        if ((equal_button_width * 2) + ITIDY_ADV_SPACE_X > reference_width)
        {
            equal_button_width = (reference_width - ITIDY_ADV_SPACE_X) / 2;
        }
    }

    init_new_gadget(&ng, adv_data, text_attr);
    button_left = label_column_x;
    ng.ng_LeftEdge = button_left;
    ng.ng_TopEdge = button_row_y;
    ng.ng_Width = equal_button_width;
    ng.ng_Height = button_height;
    ng.ng_GadgetID = GID_ADV_OK;
    ng.ng_Flags = PLACETEXT_IN;
    ng.ng_GadgetText = "OK";
    adv_data->ok_btn = gad = CreateGadget(BUTTON_KIND, gad, &ng,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create OK button\n");
        goto cleanup;
    }

    init_new_gadget(&ng, adv_data, text_attr);
    ng.ng_LeftEdge = button_left + equal_button_width + ITIDY_ADV_SPACE_X;
    ng.ng_TopEdge = button_row_y;
    ng.ng_Width = equal_button_width;
    ng.ng_Height = button_height;
    ng.ng_GadgetID = GID_ADV_CANCEL;
    ng.ng_GadgetText = "Cancel";
    adv_data->cancel_btn = gad = CreateGadget(BUTTON_KIND, gad, &ng,
        TAG_END);
    if (!gad)
    {
        printf("ERROR: Failed to create Cancel button\n");
        goto cleanup;
    }

    update_content_bottom(&content_bottom, button_row_y, button_height);

    window_width = border_left + ITIDY_ADV_MARGIN_LEFT + reference_width + ITIDY_ADV_MARGIN_RIGHT + border_right;
    window_height = border_top + ITIDY_ADV_MARGIN_TOP + (content_bottom - content_top) + ITIDY_ADV_MARGIN_BOTTOM + border_bottom;

    success = TRUE;
    result = adv_data->glist;

cleanup:
    if (!success && adv_data->glist)
    {
        FreeGadgets(adv_data->glist);
        adv_data->glist = NULL;
    }

    if (draw_info)
    {
        FreeScreenDrawInfo(screen, draw_info);
    }

    if (success)
    {
        if (out_window_width)
        {
            *out_window_width = window_width;
        }
        if (out_window_height)
        {
            *out_window_height = window_height;
        }
    }

    return result;
}

/*------------------------------------------------------------------------*/
/* Public Functions                                                       */
/*------------------------------------------------------------------------*/

BOOL open_itidy_advanced_window(struct iTidyAdvancedWindow *adv_data, 
                                 LayoutPreferences *prefs)
{
    struct Gadget *glist;
    UWORD window_width = 0;
    UWORD window_height = 0;
    
    if (!adv_data || !prefs)
    {
        printf("ERROR: NULL pointer passed to open_itidy_advanced_window\n");
        return FALSE;
    }
    
    /* Initialize structure */
    memset(adv_data, 0, sizeof(struct iTidyAdvancedWindow));
    adv_data->prefs = prefs;
    adv_data->changes_accepted = FALSE;
    
    /* Load current preferences into local variables */
    adv_data->aspect_preset_selected = get_aspect_ratio_preset_index(prefs);
    adv_data->custom_aspect_width = prefs->customAspectWidth;
    adv_data->custom_aspect_height = prefs->customAspectHeight;
    adv_data->overflow_mode_selected = prefs->overflowMode;
    adv_data->spacing_x_value = prefs->iconSpacingX;
    adv_data->spacing_y_value = prefs->iconSpacingY;
    adv_data->min_icons_per_row = prefs->minIconsPerRow;
    adv_data->max_icons_per_row = prefs->maxIconsPerRow;
    adv_data->max_auto_enabled = (prefs->maxIconsPerRow == 0);  /* Auto if 0 */
    adv_data->max_width_pct_selected = get_max_width_pct_index(prefs->maxWindowWidthPct);
    adv_data->vertical_align_selected = prefs->textAlignment;  /* 0=Top, 1=Middle, 2=Bottom */
    adv_data->reverse_sort_enabled = prefs->reverseSort;        /* Load reverse sort setting */
    adv_data->optimize_cols_enabled = prefs->useColumnWidthOptimization;  /* Load optimize columns setting */
    adv_data->skip_hidden_enabled = prefs->skipHiddenFolders;  /* Load skip hidden folders setting */
    adv_data->column_layout_enabled = prefs->centerIconsInColumn;  /* Load column layout setting */
    
    log_debug(LOG_GUI, "Loading prefs into adv_data on window open:\n");
    log_debug(LOG_GUI, "  prefs->iconSpacingX = %hu\n", prefs->iconSpacingX);
    log_debug(LOG_GUI, "  prefs->iconSpacingY = %hu\n", prefs->iconSpacingY);
    log_debug(LOG_GUI, "  prefs->maxWindowWidthPct = %ld\n", (long)prefs->maxWindowWidthPct);
    log_debug(LOG_GUI, "  prefs->textAlignment = %ld\n", (long)prefs->textAlignment);
    log_debug(LOG_GUI, "  adv_data->max_width_pct_selected = %ld\n", (long)adv_data->max_width_pct_selected);
    log_debug(LOG_GUI, "  adv_data->vertical_align_selected = %ld\n", (long)adv_data->vertical_align_selected);
    log_debug(LOG_GUI, "  prefs->overflowMode = %ld\n", (long)prefs->overflowMode);
    log_debug(LOG_GUI, "  prefs->aspectRatio = %d\n", prefs->aspectRatio);
    log_debug(LOG_GUI, "  prefs->reverseSort = %s\n", prefs->reverseSort ? "YES" : "NO");
    
    /* Get Workbench screen */
    adv_data->screen = LockPubScreen(NULL);
    if (!adv_data->screen)
    {
        printf("ERROR: Failed to lock Workbench screen\n");
        return FALSE;
    }
    
    /* Get visual info for GadTools */
    adv_data->visual_info = GetVisualInfo(adv_data->screen, TAG_END);
    if (!adv_data->visual_info)
    {
        printf("ERROR: Failed to get visual info\n");
        UnlockPubScreen(NULL, adv_data->screen);
        return FALSE;
    }
    
    /* Create gadgets */
    glist = create_advanced_gadgets(adv_data, &window_width, &window_height);
    if (!glist)
    {
        printf("ERROR: Failed to create gadgets\n");
        FreeVisualInfo(adv_data->visual_info);
        UnlockPubScreen(NULL, adv_data->screen);
        return FALSE;
    }
    
    /* Open the window */
    adv_data->window = OpenWindowTags(NULL,
        WA_Title, ITIDY_ADV_WINDOW_TITLE,
        WA_Left, ITIDY_ADV_WINDOW_LEFT,
        WA_Top, ITIDY_ADV_WINDOW_TOP,
        WA_Width, window_width ? window_width : (ITIDY_ADV_WINDOW_WIDTH_CHARS * 8),
        WA_Height, window_height ? window_height : 240,
        WA_DragBar, TRUE,
        WA_DepthGadget, TRUE,
        WA_CloseGadget, TRUE,
        WA_Activate, TRUE,
        WA_PubScreen, adv_data->screen,
        WA_Gadgets, glist,
        WA_IDCMP, IDCMP_CLOSEWINDOW | IDCMP_GADGETUP | IDCMP_REFRESHWINDOW,
        TAG_END);
    
    if (!adv_data->window)
    {
        printf("ERROR: Failed to open advanced settings window\n");
        FreeGadgets(adv_data->glist);
        FreeVisualInfo(adv_data->visual_info);
        UnlockPubScreen(NULL, adv_data->screen);
        return FALSE;
    }
    
    adv_data->window_open = TRUE;
    
    /* Load current preferences into gadgets (in case they were changed since last open) */
    load_preferences_to_advanced_window(adv_data);
    
    /* Refresh gadgets */
    GT_RefreshWindow(adv_data->window, NULL);
    
    printf("Advanced Settings window opened successfully\n");
    return TRUE;
}

void close_itidy_advanced_window(struct iTidyAdvancedWindow *adv_data)
{
    if (!adv_data)
    {
        return;
    }
    
    /* Close window */
    if (adv_data->window)
    {
        CloseWindow(adv_data->window);
        adv_data->window = NULL;
    }
    
    /* Free gadgets */
    if (adv_data->glist)
    {
        FreeGadgets(adv_data->glist);
        adv_data->glist = NULL;
    }
    
    /* Free visual info */
    if (adv_data->visual_info)
    {
        FreeVisualInfo(adv_data->visual_info);
        adv_data->visual_info = NULL;
    }
    
    /* Unlock screen */
    if (adv_data->screen)
    {
        UnlockPubScreen(NULL, adv_data->screen);
        adv_data->screen = NULL;
    }
    
    adv_data->window_open = FALSE;
    
    printf("Advanced Settings window closed\n");
}

void set_custom_ratio_gadgets_state(struct iTidyAdvancedWindow *adv_data, 
                                    BOOL enable)
{
    if (!adv_data || !adv_data->window)
    {
        return;
    }
    
    /* Enable/disable custom width gadget */
    if (adv_data->custom_width_int)
    {
        GT_SetGadgetAttrs(adv_data->custom_width_int, adv_data->window, NULL,
            GA_Disabled, !enable,
            TAG_END);
    }
    
    /* Enable/disable custom height gadget */
    if (adv_data->custom_height_int)
    {
        GT_SetGadgetAttrs(adv_data->custom_height_int, adv_data->window, NULL,
            GA_Disabled, !enable,
            TAG_END);
    }
}

void set_max_icons_gadget_state(struct iTidyAdvancedWindow *adv_data,
                                BOOL auto_enabled)
{
    if (!adv_data || !adv_data->window)
    {
        return;
    }
    
    /* Disable max icons/row gadget when Auto is enabled */
    if (adv_data->max_icons_row_int)
    {
        GT_SetGadgetAttrs(adv_data->max_icons_row_int, adv_data->window, NULL,
            GA_Disabled, auto_enabled,
            TAG_END);
    }
}

void update_max_width_pct_gadget_state(struct iTidyAdvancedWindow *adv_data)
{
    BOOL manual_mode;
    
    if (!adv_data || !adv_data->window)
    {
        return;
    }
    
    /* Disable max width pct gadget when in manual mode (not Auto) */
    manual_mode = !adv_data->max_auto_enabled;
    
    if (adv_data->max_width_pct_cycle)
    {
        GT_SetGadgetAttrs(adv_data->max_width_pct_cycle, adv_data->window, NULL,
            GA_Disabled, manual_mode,
            TAG_END);
    }
}

void save_advanced_window_to_preferences(struct iTidyAdvancedWindow *adv_data)
{
    if (!adv_data || !adv_data->prefs)
    {
        printf("ERROR: NULL pointer in save_advanced_window_to_preferences\n");
        return;
    }
    
    /* Save aspect ratio settings */
    if (adv_data->aspect_preset_selected == ASPECT_PRESET_CUSTOM)
    {
        /* Using custom aspect ratio */
        adv_data->prefs->useCustomAspectRatio = TRUE;
        adv_data->prefs->customAspectWidth = adv_data->custom_aspect_width;
        adv_data->prefs->customAspectHeight = adv_data->custom_aspect_height;
        
        /* Calculate aspect ratio from custom values (fixed-point: scaled by 1000) */
        if (adv_data->custom_aspect_height > 0)
        {
            adv_data->prefs->aspectRatio = 
                (adv_data->custom_aspect_width * 1000) / 
                adv_data->custom_aspect_height;
        }
        else
        {
            /* Invalid height, default to Classic */
            adv_data->prefs->aspectRatio = 1600;  /* 1.6 * 1000 */
            printf("WARNING: Invalid custom aspect height, using default 1.6\n");
        }
    }
    else
    {
        /* Using preset aspect ratio */
        adv_data->prefs->useCustomAspectRatio = FALSE;
        adv_data->prefs->aspectRatio = 
            aspect_ratio_presets[adv_data->aspect_preset_selected];
    }
    
    /* Save overflow mode */
    adv_data->prefs->overflowMode = adv_data->overflow_mode_selected;
    
    /* Save spacing values */
    adv_data->prefs->iconSpacingX = adv_data->spacing_x_value;
    adv_data->prefs->iconSpacingY = adv_data->spacing_y_value;
    
    log_debug(LOG_GUI, "  Saved prefs->iconSpacingX = %hu\n", adv_data->prefs->iconSpacingX);
    log_debug(LOG_GUI, "  Saved prefs->iconSpacingY = %hu\n", adv_data->prefs->iconSpacingY);
    
    /* Save column limits */
    adv_data->prefs->minIconsPerRow = adv_data->min_icons_per_row;
    
    /* Save max icons per row: 0 if Auto mode, otherwise the manual value */
    if (adv_data->max_auto_enabled)
    {
        adv_data->prefs->maxIconsPerRow = 0;  /* Auto mode */
    }
    else
    {
        adv_data->prefs->maxIconsPerRow = adv_data->max_icons_per_row;
    }
    
    /* Save max window width percentage */
    adv_data->prefs->maxWindowWidthPct = get_max_width_pct_value(
        adv_data->max_width_pct_selected, adv_data->prefs);
    
    /* Save vertical alignment */
    adv_data->prefs->textAlignment = adv_data->vertical_align_selected;
    
    /* Save reverse sort setting */
    adv_data->prefs->reverseSort = adv_data->reverse_sort_enabled;
    
    /* Save optimize columns setting */
    adv_data->prefs->useColumnWidthOptimization = adv_data->optimize_cols_enabled;
    
    /* Save skip hidden folders setting */
    adv_data->prefs->skipHiddenFolders = adv_data->skip_hidden_enabled;
    
    /* Save column layout setting */
    adv_data->prefs->centerIconsInColumn = adv_data->column_layout_enabled;
    
    log_debug(LOG_GUI, "save_advanced_window_to_preferences() called:\n");
    log_debug(LOG_GUI, "  adv_data->max_width_pct_selected = %ld\n", (long)adv_data->max_width_pct_selected);
    log_debug(LOG_GUI, "  adv_data->vertical_align_selected = %ld\n", (long)adv_data->vertical_align_selected);
    log_debug(LOG_GUI, "  adv_data->overflow_mode_selected = %ld\n", (long)adv_data->overflow_mode_selected);
    log_debug(LOG_GUI, "  adv_data->aspect_preset_selected = %ld\n", (long)adv_data->aspect_preset_selected);
    log_debug(LOG_GUI, "  adv_data->reverse_sort_enabled = %s\n", adv_data->reverse_sort_enabled ? "YES" : "NO");
    log_debug(LOG_GUI, "  Saved prefs->maxWindowWidthPct = %ld\n", (long)adv_data->prefs->maxWindowWidthPct);
    log_debug(LOG_GUI, "  Saved prefs->textAlignment = %ld\n", (long)adv_data->prefs->textAlignment);
    log_debug(LOG_GUI, "  Saved prefs->overflowMode = %ld\n", (long)adv_data->prefs->overflowMode);
    log_debug(LOG_GUI, "  Saved prefs->reverseSort = %s\n", adv_data->prefs->reverseSort ? "YES" : "NO");
    
    printf("Advanced settings saved to preferences:\n");
    {
        LONG ratio_value = adv_data->prefs->aspectRatio;
        LONG ratio_whole = ratio_value / 1000;
        LONG ratio_fraction = (ratio_value % 1000) / 10;  /* two decimal digits */
        if (ratio_fraction < 0)
        {
            ratio_fraction = -ratio_fraction;
        }
        printf("  Aspect Ratio: %ld.%02ld (Custom: %s)\n",
               ratio_whole,
               ratio_fraction,
               adv_data->prefs->useCustomAspectRatio ? "YES" : "NO");
    }
    printf("  Overflow Mode: %d\n", adv_data->prefs->overflowMode);
    printf("  Spacing: %hu x %hu\n", 
           adv_data->prefs->iconSpacingX, 
           adv_data->prefs->iconSpacingY);
    printf("  Min Icons/Row: %hu\n", adv_data->prefs->minIconsPerRow);
    printf("  Max Icons/Row: %hu (%s)\n", 
           adv_data->prefs->maxIconsPerRow,
           adv_data->prefs->maxIconsPerRow == 0 ? "AUTO" : "MANUAL");
    printf("  Max Window Width: %hu%% (%s)\n",
           adv_data->prefs->maxWindowWidthPct,
           adv_data->prefs->maxWindowWidthPct == 0 ? "AUTO" : "MANUAL");
    printf("  Vertical Alignment: %s\n",
           vertical_align_labels[adv_data->prefs->textAlignment]);
    printf("  Reverse Sort: %s\n",
           adv_data->prefs->reverseSort ? "YES" : "NO");
}

BOOL handle_advanced_window_events(struct iTidyAdvancedWindow *adv_data)
{
    struct IntuiMessage *msg;
    ULONG msg_class;
    UWORD msg_code;
    struct Gadget *gad;
    BOOL continue_running = TRUE;
    
    if (!adv_data || !adv_data->window)
    {
        return FALSE;
    }
    
    /* Wait for messages */
    while ((msg = GT_GetIMsg(adv_data->window->UserPort)))
    {
        msg_class = msg->Class;
        msg_code = msg->Code;
        gad = (struct Gadget *)msg->IAddress;
        
        /* Reply to message */
        GT_ReplyIMsg(msg);
        
        /* Handle message */
        switch (msg_class)
        {
            case IDCMP_CLOSEWINDOW:
                printf("Advanced window close requested\n");
                adv_data->changes_accepted = FALSE;
                continue_running = FALSE;
                break;
                
            case IDCMP_REFRESHWINDOW:
                GT_BeginRefresh(adv_data->window);
                GT_EndRefresh(adv_data->window, TRUE);
                break;
                
            case IDCMP_GADGETUP:
                switch (gad->GadgetID)
                {
                    case GID_ADV_OK:
                        printf("OK button clicked\n");
                        
                        /* Read all gadget values into local variables */
                        {
                            LONG temp_number;
                            
                            /* Custom width */
                            GT_GetGadgetAttrs(adv_data->custom_width_int, 
                                            adv_data->window, NULL,
                                            GTIN_Number, &temp_number, TAG_END);
                            adv_data->custom_aspect_width = (UWORD)temp_number;
                            
                            /* Custom height */
                            GT_GetGadgetAttrs(adv_data->custom_height_int, 
                                            adv_data->window, NULL,
                                            GTIN_Number, &temp_number, TAG_END);
                            adv_data->custom_aspect_height = (UWORD)temp_number;
                            
                            /* Min icons per row */
                            GT_GetGadgetAttrs(adv_data->min_icons_row_int, 
                                            adv_data->window, NULL,
                                            GTIN_Number, &temp_number, TAG_END);
                            adv_data->min_icons_per_row = (UWORD)temp_number;
                            
                            /* Max icons per row */
                            GT_GetGadgetAttrs(adv_data->max_icons_row_int, 
                                            adv_data->window, NULL,
                                            GTIN_Number, &temp_number, TAG_END);
                            adv_data->max_icons_per_row = (UWORD)temp_number;
                            
                            /* Auto checkbox */
                            GT_GetGadgetAttrs(adv_data->max_auto_checkbox,
                                            adv_data->window, NULL,
                                            GTCB_Checked, &temp_number, TAG_END);
                            adv_data->max_auto_enabled = (BOOL)temp_number;
                            
                            /* Spacing X */
                            GT_GetGadgetAttrs(adv_data->spacing_x_int, 
                                            adv_data->window, NULL,
                                            GTIN_Number, &temp_number, TAG_END);
                            adv_data->spacing_x_value = (UWORD)temp_number;
                            
                            /* Spacing Y */
                            GT_GetGadgetAttrs(adv_data->spacing_y_int, 
                                            adv_data->window, NULL,
                                            GTIN_Number, &temp_number, TAG_END);
                            adv_data->spacing_y_value = (UWORD)temp_number;
                            
                            log_debug(LOG_GUI, "Read gadget values on OK click:\n");
                            log_debug(LOG_GUI, "  spacing_x_value = %hu\n", adv_data->spacing_x_value);
                            log_debug(LOG_GUI, "  spacing_y_value = %hu\n", adv_data->spacing_y_value);
                            log_debug(LOG_GUI, "  max_width_pct_selected = %ld\n", (long)adv_data->max_width_pct_selected);
                            GT_GetGadgetAttrs(adv_data->max_width_pct_cycle,
                                            adv_data->window, NULL,
                                            GTCY_Active, &temp_number, TAG_END);
                            adv_data->max_width_pct_selected = (WORD)temp_number;
                            
                            /* Aspect ratio cycle gadget */
                            GT_GetGadgetAttrs(adv_data->aspect_ratio_cycle,
                                            adv_data->window, NULL,
                                            GTCY_Active, &temp_number, TAG_END);
                            adv_data->aspect_preset_selected = (WORD)temp_number;
                            
                            /* Overflow mode cycle gadget */
                            GT_GetGadgetAttrs(adv_data->overflow_mode_cycle,
                                            adv_data->window, NULL,
                                            GTCY_Active, &temp_number, TAG_END);
                            adv_data->overflow_mode_selected = (WORD)temp_number;
                            
                            /* Vertical alignment cycle gadget */
                            GT_GetGadgetAttrs(adv_data->vertical_align_cycle,
                                            adv_data->window, NULL,
                                            GTCY_Active, &temp_number, TAG_END);
                            adv_data->vertical_align_selected = (WORD)temp_number;
                            
                            log_debug(LOG_GUI, "Read gadget values on OK click:\n");
                            log_debug(LOG_GUI, "  max_width_pct_selected = %ld\n", (long)adv_data->max_width_pct_selected);
                            log_debug(LOG_GUI, "  vertical_align_selected = %ld\n", (long)adv_data->vertical_align_selected);
                            log_debug(LOG_GUI, "  overflow_mode_selected = %ld\n", (long)adv_data->overflow_mode_selected);
                            log_debug(LOG_GUI, "  aspect_preset_selected = %ld\n", (long)adv_data->aspect_preset_selected);
                        }
                        
                        /* Save to preferences */
                        save_advanced_window_to_preferences(adv_data);
                        adv_data->changes_accepted = TRUE;
                        continue_running = FALSE;
                        break;
                        
                    case GID_ADV_CANCEL:
                        printf("Cancel button clicked\n");
                        adv_data->changes_accepted = FALSE;
                        continue_running = FALSE;
                        break;
                        
                    case GID_ADV_ASPECT_RATIO:
                        /* CRITICAL: Use msg_code for cycle gadgets (not GT_GetGadgetAttrs) */
                        adv_data->aspect_preset_selected = msg_code;
                        printf("Aspect ratio changed to: %s\n", 
                               aspect_ratio_labels[adv_data->aspect_preset_selected]);
                        
                        /* Enable/disable custom ratio gadgets */
                        set_custom_ratio_gadgets_state(adv_data, 
                            adv_data->aspect_preset_selected == ASPECT_PRESET_CUSTOM);
                        break;
                        
                    case GID_ADV_OVERFLOW_MODE:
                        /* CRITICAL: Use msg_code for cycle gadgets (not GT_GetGadgetAttrs) */
                        adv_data->overflow_mode_selected = msg_code;
                        printf("Overflow mode changed to: %s\n", 
                               overflow_mode_labels[adv_data->overflow_mode_selected]);
                        break;
                        
                    case GID_ADV_MAX_AUTO_CHECKBOX:
                        /* Auto checkbox toggled */
                        {
                            LONG checked;
                            GT_GetGadgetAttrs(adv_data->max_auto_checkbox,
                                            adv_data->window, NULL,
                                            GTCB_Checked, &checked, TAG_END);
                            adv_data->max_auto_enabled = (BOOL)checked;
                            
                            printf("Auto Max Icons/Row: %s\n",
                                   adv_data->max_auto_enabled ? "ENABLED" : "DISABLED");
                            
                            /* Enable/disable the max icons/row integer gadget */
                            set_max_icons_gadget_state(adv_data, adv_data->max_auto_enabled);
                            
                            /* Enable/disable the max window width pct gadget */
                            update_max_width_pct_gadget_state(adv_data);
                        }
                        break;
                        
                    case GID_ADV_MAX_WIDTH_PCT:
                        /* Max window width percentage changed */
                        adv_data->max_width_pct_selected = msg_code;
                        printf("Max window width changed to: %s\n", 
                               max_width_pct_labels[adv_data->max_width_pct_selected]);
                        break;
                    
                    case GID_ADV_VERTICAL_ALIGN:
                        /* Vertical alignment changed */
                        adv_data->vertical_align_selected = msg_code;
                        printf("Vertical alignment changed to: %s\n",
                               vertical_align_labels[adv_data->vertical_align_selected]);
                        break;
                    
                    case GID_ADV_REVERSE_SORT:
                        {
                            ULONG checked = 0;
                            GT_GetGadgetAttrs(gad, adv_data->window, NULL,
                                GTCB_Checked, &checked,
                                TAG_END);
                            adv_data->reverse_sort_enabled = (BOOL)checked;
                            printf("Reverse Sort: %s\n", 
                                   adv_data->reverse_sort_enabled ? "ENABLED" : "DISABLED");
                        }
                        break;
                    
                    case GID_ADV_OPTIMIZE_COLS:
                        {
                            ULONG checked = 0;
                            GT_GetGadgetAttrs(gad, adv_data->window, NULL,
                                GTCB_Checked, &checked,
                                TAG_END);
                            adv_data->optimize_cols_enabled = (BOOL)checked;
                            printf("Optimize Column Widths: %s\n", 
                                   adv_data->optimize_cols_enabled ? "ENABLED" : "DISABLED");
                        }
                        break;
                    
                    case GID_ADV_SKIP_HIDDEN:
                        {
                            ULONG checked = 0;
                            GT_GetGadgetAttrs(gad, adv_data->window, NULL,
                                GTCB_Checked, &checked,
                                TAG_END);
                            adv_data->skip_hidden_enabled = (BOOL)checked;
                            printf("Skip Hidden Folders: %s\n", 
                                   adv_data->skip_hidden_enabled ? "ENABLED" : "DISABLED");
                        }
                        break;
                    
                    case GID_ADV_COLUMN_LAYOUT:
                        {
                            ULONG checked = 0;
                            GT_GetGadgetAttrs(gad, adv_data->window, NULL,
                                GTCB_Checked, &checked,
                                TAG_END);
                            adv_data->column_layout_enabled = (BOOL)checked;
                            printf("Column Layout: %s\n", 
                                   adv_data->column_layout_enabled ? "ENABLED" : "DISABLED");
                        }
                        break;
                    
                    case GID_ADV_BETA_OPTIONS:
                        /* Open Beta Options window */
                        {
                            struct iTidyBetaOptionsWindow beta_window;
                            
                            printf("Opening Beta Options window...\n");
                            
                            if (open_itidy_beta_options_window(&beta_window, adv_data->prefs))
                            {
                                /* Run the beta options event loop */
                                while (handle_beta_options_window_events(&beta_window))
                                {
                                    WaitPort(beta_window.window->UserPort);
                                }
                                
                                /* Close the beta options window */
                                close_itidy_beta_options_window(&beta_window);
                                
                                /* Log result */
                                if (beta_window.changes_accepted)
                                {
                                    printf("Beta options saved\n");
                                }
                                else
                                {
                                    printf("Beta options cancelled\n");
                                }
                            }
                            else
                            {
                                printf("ERROR: Failed to open Beta Options window\n");
                            }
                        }
                        break;
                        
                    case GID_ADV_CUSTOM_WIDTH:
                    case GID_ADV_CUSTOM_HEIGHT:
                    case GID_ADV_SPACING_X:
                    case GID_ADV_SPACING_Y:
                    case GID_ADV_MIN_ICONS_ROW:
                    case GID_ADV_MAX_ICONS_ROW:
                        /* These are updated when OK is clicked */
                        break;
                        
                    default:
                        printf("Unknown gadget ID: %lu\n", (unsigned long)gad->GadgetID);
                        break;
                }
                break;
        }
    }
    
    return continue_running;
}

void load_preferences_to_advanced_window(struct iTidyAdvancedWindow *adv_data)
{
    if (!adv_data || !adv_data->window || !adv_data->prefs)
    {
        printf("ERROR: NULL pointer in load_preferences_to_advanced_window\n");
        return;
    }
    
    log_debug(LOG_GUI, "load_preferences_to_advanced_window() called:\n");
    log_debug(LOG_GUI, "  Setting max_width_pct_cycle to: %ld\n", (long)adv_data->max_width_pct_selected);
    log_debug(LOG_GUI, "  Setting vertical_align_cycle to: %ld\n", (long)adv_data->vertical_align_selected);
    log_debug(LOG_GUI, "  Setting overflow_mode_cycle to: %ld\n", (long)adv_data->overflow_mode_selected);
    log_debug(LOG_GUI, "  Setting aspect_ratio_cycle to: %ld\n", (long)adv_data->aspect_preset_selected);
    
    /* Aspect ratio preset */
    GT_SetGadgetAttrs(adv_data->aspect_ratio_cycle, adv_data->window, NULL,
        GTCY_Active, adv_data->aspect_preset_selected,
        TAG_END);
    
    /* Custom aspect ratio values */
    GT_SetGadgetAttrs(adv_data->custom_width_int, adv_data->window, NULL,
        GTIN_Number, adv_data->custom_aspect_width,
        TAG_END);
    
    GT_SetGadgetAttrs(adv_data->custom_height_int, adv_data->window, NULL,
        GTIN_Number, adv_data->custom_aspect_height,
        TAG_END);
    
    /* Overflow mode */
    GT_SetGadgetAttrs(adv_data->overflow_mode_cycle, adv_data->window, NULL,
        GTCY_Active, adv_data->overflow_mode_selected,
        TAG_END);
    
    /* Spacing integers */
    GT_SetGadgetAttrs(adv_data->spacing_x_int, adv_data->window, NULL,
        GTIN_Number, adv_data->spacing_x_value,
        TAG_END);
    
    GT_SetGadgetAttrs(adv_data->spacing_y_int, adv_data->window, NULL,
        GTIN_Number, adv_data->spacing_y_value,
        TAG_END);
    
    /* Column limits */
    GT_SetGadgetAttrs(adv_data->min_icons_row_int, adv_data->window, NULL,
        GTIN_Number, adv_data->min_icons_per_row,
        TAG_END);
    
    /* Auto checkbox */
    GT_SetGadgetAttrs(adv_data->max_auto_checkbox, adv_data->window, NULL,
        GTCB_Checked, adv_data->max_auto_enabled,
        TAG_END);
    
    /* Max icons/row (only if not Auto) */
    GT_SetGadgetAttrs(adv_data->max_icons_row_int, adv_data->window, NULL,
        GTIN_Number, adv_data->max_icons_per_row > 0 ? adv_data->max_icons_per_row : 5,
        GA_Disabled, adv_data->max_auto_enabled,
        TAG_END);
    
    /* Max window width percentage */
    GT_SetGadgetAttrs(adv_data->max_width_pct_cycle, adv_data->window, NULL,
        GTCY_Active, adv_data->max_width_pct_selected,
        GA_Disabled, !adv_data->max_auto_enabled,
        TAG_END);
    
    /* Vertical alignment */
    GT_SetGadgetAttrs(adv_data->vertical_align_cycle, adv_data->window, NULL,
        GTCY_Active, adv_data->vertical_align_selected,
        TAG_END);
    
    /* Reverse sort checkbox */
    GT_SetGadgetAttrs(adv_data->reverse_sort_check, adv_data->window, NULL,
        GTCB_Checked, adv_data->reverse_sort_enabled,
        TAG_END);
    
    /* Enable/disable custom ratio gadgets based on selection */
    set_custom_ratio_gadgets_state(adv_data, 
        adv_data->aspect_preset_selected == ASPECT_PRESET_CUSTOM);
    
    /* Enable/disable max icons gadget based on Auto checkbox */
    set_max_icons_gadget_state(adv_data, adv_data->max_auto_enabled);
    
    /* Enable/disable max width pct gadget based on Auto checkbox */
    update_max_width_pct_gadget_state(adv_data);
    
    printf("Preferences loaded into advanced window\n");
}
